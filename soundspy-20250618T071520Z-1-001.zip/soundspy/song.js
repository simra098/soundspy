function playPause(audioID) {
	var audio = document.getElementById(audioID);
	if (audio.paused) {
	  audio.play();
	  document.getElementById("playPauseBTN" + audioID.substr(5)).innerHTML = "Pause ❚❚";
	} else {
	  audio.pause();
	  document.getElementById("playPauseBTN" + audioID.substr(5)).innerHTML = "Play ►";
	}
  }